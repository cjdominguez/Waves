"""
Summary: Waves
    Surfer (Mark Zuckerburg) dropin to catch the waves & some coins
Analysis:
    scrolling screen, various sized waves, surfer,
    surfer jumps the waves over the line to collect coins,
    screen scrolls, if surfer get caught on the left edge, game over
    landing too hard or losing speed causes a wipeout, game over
Design:
  * Has a Welcome and Instruction screen
  * has a 'Game over' (lose) screen (player falls off left side of screen) and
  * has a 'Game Won' screen (21 coins collected)
      halts the game or allow the user to restart the game
  game play
  1 player - 1 character
  once the player has moved 25% across the screen the screen scrolls automatically
  directional key control movement of avatar
      Up key is jump, then gravity has the player drop on the screen
  coins are randomly placed above the line for avatar to crash/collect, more coins are added
  as the screen scrolls right
  Waves randomly roll across screen
"""

import arcade
import random
import os

# set up directory path, may be needed
file_path = os.path.dirname(os.path.abspath(__file__))
os.chdir(file_path)

"""Music information
Chase by Alexander Nakarada | https://www.serpentsoundstudios.com
Music promoted by https://www.free-stock-music.com
Attribution 4.0 International (CC BY 4.0)
https://creativecommons.org/licenses/by/4.0/
"""

MUSIC_VOLUME = 0.3
MUSIC_NAME = str("Chase by Alexander Nakarada | https://www.serpentsoundstudios.com | " +
                 "Music promoted by https://www.free-stock-music.com | " +
                 "Attribution 4.0 International (CC BY 4.0) | " + "https://creativecommons.org/licenses/by/4.0/")

# set constants
strInstructions = "Using the directional keys, surf the waves with Mark Zuckerberg and collect 21 coins"

strInstructions2 = "Don't fall too far back or the game is over!"
WIDTH = SCREEN_WIDTH = 800
HEIGHT = SCREEN_HEIGHT = 600
SCREEN_TITLE = "Waves"
SPRITE_SCALING = 0.5

# How many pixels to keep as a minimum margin between the character
# and the edge of the screen.
VIEWPORT_MARGIN = 40
MOVEMENT_SPEED = 5
GAME_LENGTH = 10
GRAVITY = .5
PLAYER_JUMP_SPEED = 10
WIN_COINS = 20
GAME_BEGIN_SOUND = arcade.load_sound(":resources:sounds/upgrade1.wav")
GAME_OVER_SOUND = arcade.load_sound(":resources:sounds/laser1.mp3")
GAME_WON_SOUND = arcade.load_sound(":resources:sounds/secret4.wav")


class MenuView(arcade.View):
    """Welcome screen - mouse click to continue"""

    def on_show(self):
        arcade.set_background_color(arcade.color.SAE)
        arcade.set_viewport(0, SCREEN_WIDTH - 1, 0, SCREEN_HEIGHT - 1)

    def on_draw(self):
        arcade.start_render()

        arcade.draw_lrtb_rectangle_filled(0, 1000, 150, 0, arcade.csscolor.ROYAL_BLUE)
        arcade.draw_line(250, 30, 50, 30, arcade.color.WHITE, 3)
        arcade.draw_line(150, 45, 0, 45, arcade.color.WHITE, 3)
        arcade.draw_line(250, 60, 50, 60, arcade.color.WHITE, 3)
        arcade.draw_line(150, 75, 0, 75, arcade.color.WHITE, 3)
        arcade.draw_line(250, 90, 50, 90, arcade.color.WHITE, 3)
        arcade.draw_line(150, 105, 0, 105, arcade.color.WHITE, 3)
        arcade.draw_line(250, 120, 50, 120, arcade.color.WHITE, 3)
        arcade.draw_line(150, 135, 0, 135, arcade.color.WHITE, 3)
        arcade.draw_line(175, 135, 375, 135, arcade.color.WHITE, 3)
        arcade.draw_line(175, 105, 375, 105, arcade.color.WHITE, 3)
        arcade.draw_line(175, 75, 375, 75, arcade.color.WHITE, 3)
        arcade.draw_line(175, 45, 375, 45, arcade.color.WHITE, 3)
        arcade.draw_line(275, 60, 475, 60, arcade.color.WHITE, 3)
        arcade.draw_line(275, 90, 475, 90, arcade.color.WHITE, 3)
        arcade.draw_line(275, 120, 475, 120, arcade.color.WHITE, 3)
        arcade.draw_line(400, 135, 600, 135, arcade.color.WHITE, 3)
        arcade.draw_line(400, 105, 600, 105, arcade.color.WHITE, 3)
        arcade.draw_line(400, 75, 600, 75, arcade.color.WHITE, 3)
        arcade.draw_line(500, 120, 700, 120, arcade.color.WHITE, 3)
        arcade.draw_line(500, 90, 700, 90, arcade.color.WHITE, 3)
        arcade.draw_line(625, 105, 825, 105, arcade.color.WHITE, 3)
        arcade.draw_line(625, 135, 825, 135, arcade.color.WHITE, 3)

        # sun
        arcade.draw_circle_filled(500, 550, 40, arcade.color.YELLOW)

        # Rays to the left, right, up, and down
        arcade.draw_line(500, 550, 400, 550, arcade.color.YELLOW, 3)
        arcade.draw_line(500, 550, 600, 550, arcade.color.YELLOW, 3)
        arcade.draw_line(500, 550, 500, 450, arcade.color.YELLOW, 3)
        arcade.draw_line(500, 550, 500, 650, arcade.color.YELLOW, 3)

        # Diagonal rays
        arcade.draw_line(500, 550, 550, 600, arcade.color.YELLOW, 3)
        arcade.draw_line(500, 550, 550, 500, arcade.color.YELLOW, 3)
        arcade.draw_line(500, 550, 450, 600, arcade.color.YELLOW, 3)
        arcade.draw_line(500, 550, 450, 500, arcade.color.YELLOW, 3)

        # Title Screen
        arcade.draw_text("Welcome to", WIDTH / 6, HEIGHT / 2 + 140,
                         arcade.color.BLACK, font_size=36, anchor_x="center")
        arcade.draw_text("Waves", WIDTH / 2, HEIGHT / 2 - 100,
                         arcade.color.BLACK, font_size=200, anchor_x="center")
        arcade.draw_text("Click to advance", WIDTH / 2, HEIGHT / 2 - 125,
                         arcade.color.BLACK, font_size=15, anchor_x="center")

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        arcade.play_sound(GAME_BEGIN_SOUND)
        instructions_view = InstructionView()
        self.window.show_view(instructions_view)


class InstructionView(arcade.View):
    """Instruction screen - mouse click to continue"""

    def on_show(self):
        arcade.set_background_color(arcade.color.SAE)
        # Reset the viewport, necessary if we have a scrolling game and we need
        # to reset the viewport back to the start so we can see what we draw.
        arcade.set_viewport(0, SCREEN_WIDTH - 1, 0, SCREEN_HEIGHT - 1)

    def on_draw(self):
        arcade.start_render()
        arcade.draw_text("Instructions", WIDTH / 2, HEIGHT / 1.55,
                         arcade.color.BLACK, font_size=50, anchor_x="center")
        arcade.draw_text(strInstructions, WIDTH / 2, HEIGHT / 2,
                         arcade.color.BLACK, font_size=15, anchor_x="center")
        arcade.draw_text(strInstructions2, WIDTH / 2, HEIGHT / 2.50,
                         arcade.color.BLACK, font_size=15, anchor_x="center")
        arcade.draw_text("Click to advance", WIDTH / 2, HEIGHT / 2 - 125,
                         arcade.color.BLACK, font_size=15, anchor_x="center")
        # ocean rectangle
        arcade.draw_lrtb_rectangle_filled(0, 1000, 150, 0, arcade.csscolor.ROYAL_BLUE)
        # sun
        arcade.draw_circle_filled(500, 550, 40, arcade.color.YELLOW)

        # Rays to the left, right, up, and down
        arcade.draw_line(500, 550, 400, 550, arcade.color.YELLOW, 3)
        arcade.draw_line(500, 550, 600, 550, arcade.color.YELLOW, 3)
        arcade.draw_line(500, 550, 500, 450, arcade.color.YELLOW, 3)
        arcade.draw_line(500, 550, 500, 650, arcade.color.YELLOW, 3)

        # Diagonal rays
        arcade.draw_line(500, 550, 550, 600, arcade.color.YELLOW, 3)
        arcade.draw_line(500, 550, 550, 500, arcade.color.YELLOW, 3)
        arcade.draw_line(500, 550, 450, 600, arcade.color.YELLOW, 3)
        arcade.draw_line(500, 550, 450, 500, arcade.color.YELLOW, 3)

        arcade.draw_line(250, 30, 50, 30, arcade.color.WHITE, 3)
        arcade.draw_line(150, 45, 0, 45, arcade.color.WHITE, 3)
        arcade.draw_line(250, 60, 50, 60, arcade.color.WHITE, 3)
        arcade.draw_line(150, 75, 0, 75, arcade.color.WHITE, 3)
        arcade.draw_line(250, 90, 50, 90, arcade.color.WHITE, 3)
        arcade.draw_line(150, 105, 0, 105, arcade.color.WHITE, 3)
        arcade.draw_line(250, 120, 50, 120, arcade.color.WHITE, 3)
        arcade.draw_line(150, 135, 0, 135, arcade.color.WHITE, 3)
        arcade.draw_line(175, 135, 375, 135, arcade.color.WHITE, 3)
        arcade.draw_line(175, 105, 375, 105, arcade.color.WHITE, 3)
        arcade.draw_line(175, 75, 375, 75, arcade.color.WHITE, 3)
        arcade.draw_line(175, 45, 375, 45, arcade.color.WHITE, 3)
        arcade.draw_line(275, 60, 475, 60, arcade.color.WHITE, 3)
        arcade.draw_line(275, 90, 475, 90, arcade.color.WHITE, 3)
        arcade.draw_line(275, 120, 475, 120, arcade.color.WHITE, 3)
        arcade.draw_line(400, 135, 600, 135, arcade.color.WHITE, 3)
        arcade.draw_line(400, 105, 600, 105, arcade.color.WHITE, 3)
        arcade.draw_line(400, 75, 600, 75, arcade.color.WHITE, 3)
        arcade.draw_line(500, 120, 700, 120, arcade.color.WHITE, 3)
        arcade.draw_line(500, 90, 700, 90, arcade.color.WHITE, 3)
        arcade.draw_line(625, 105, 825, 105, arcade.color.WHITE, 3)
        arcade.draw_line(625, 135, 825, 135, arcade.color.WHITE, 3)

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        arcade.play_sound(GAME_BEGIN_SOUND)
        game_view = GameView()
        game_view.setup()
        self.window.show_view(game_view)


def makeWaves(self):
    # background is sky blue, draw the water and the line.
    # Draw the water in the bottom third

    shape = arcade.create_rectangle_filled(SCREEN_WIDTH / 2, SCREEN_HEIGHT / 10,
                                           SCREEN_WIDTH * GAME_LENGTH, SCREEN_HEIGHT / 3,
                                           arcade.color.ROYAL_BLUE)

    self.shape_list.append(shape)

    # Draw the line at the top third
    shape = arcade.create_rectangle_filled(SCREEN_WIDTH / 2, SCREEN_HEIGHT * 2 / 3,
                                           SCREEN_WIDTH * GAME_LENGTH, 8,
                                           arcade.color.CORNFLOWER_BLUE)
    self.shape_list.append(shape)
    make_ball()


def makeCoins(self, screenWidth):
    for i in range(5):

        # Create the coin instance
        coin = arcade.Sprite(":resources:images/items/coinGold.png", SPRITE_SCALING)

        # Boolean variable if we successfully placed the coin
        coin_placed_successfully = False

        # Keep trying until success
        while not coin_placed_successfully:

            # Position the coins above the line and to the right of the screen
            coin.center_x = random.randrange(int(screenWidth / 2), int(screenWidth))
            coin.center_y = random.randrange(HEIGHT * 2 / 3, HEIGHT - 50)

            # See if the coin is hitting another coin
            coin_hit_list = arcade.check_for_collision_with_list(coin, self.coin_list)

            if len(coin_hit_list) == 0:
                # It is!
                coin_placed_successfully = True

        # Add the coin to the lists
        self.coin_list.append(coin)


class Ball:
    """
    Class to keep track of a ball's location and vector.
    """

    def __init__(self):
        self.x = 0
        self.y = 0
        self.change_x = 0
        self.change_y = 0
        self.size = 0
        self.color = None


def make_ball():
    """
    Function to make a new, random ball - this is the wave
    """
    ball = Ball()

    # Size of the ball
    ball.size = random.randrange(35, 150)

    # Starting position of the ball.
    # Take into account the ball size so we don't spawn on the edge.
    ball.x = 1
    ball.y = ball.size + SCREEN_WIDTH / 10

    # Speed and direction of circle
    ball.change_x = random.randrange(4, 6)
    ball.change_y = 0

    # Color
    ball.color = (arcade.color.BLUE_GREEN)

    return ball


class GameView(arcade.View):
    """game screen setup, avatar setup, coin setup,  keyboard directional keys"""

    def __init__(self):
        super().__init__()
        # shooting
        self.frame_count = 0

        self.time_taken = 0
        # Variables that will hold sprite lists
        self.player_list = None
        self.coin_list = None

        # Set up the player info
        self.player_sprite = None
        self.score = 0

        # variables to manage music
        self.music_list = []
        self.current_song = 0
        self.music = None

        # Don't show the mouse cursor
        self.window.set_mouse_visible(False)
        # cj
        self.left_pressed = False
        self.right_pressed = False
        self.up_pressed = False
        self.down_pressed = False

        """make the 1st wave"""
        self.ball_list = []
        ball = make_ball()
        self.ball_list.append(ball)

    def play_song(self):
        """stop, if something is currently playing.  restart song"""
        if self.music:
            self.music.stop()
        self.music = arcade.Sound(self.music_list[self.current_song], streaming=True)
        self.music.play(MUSIC_VOLUME)

    def setup(self):
        """set up the game and initalize the variables """
        # Sprite lists
        self.shape_list = arcade.ShapeElementList()
        self.player_list = arcade.SpriteList()
        self.coin_list = arcade.SpriteList()
        self.bullet_list = arcade.SpriteList()

        # Set up the player Mark Zukerberg Surfing
        self.score = 0
        self.player_sprite = arcade.Sprite("marky1.png",
                                           SPRITE_SCALING)
        self.player_sprite.center_x = 50
        self.player_sprite.center_y = 50
        self.player_list.append(self.player_sprite)

        # set coin sound
        self.collect_coin_sound = arcade.load_sound(":resources:sounds/coin5.wav")

        # Set music
        self.music_list = ["alexander-nakarada-chase.mp3"]
        self.current_song = 0
        self.play_song()

        """make the 1st wave"""
        self.ball_list = []
        ball = make_ball()
        self.ball_list.append(ball)

        # set the coins
        makeCoins(self, WIDTH)

        # create the physics engine with gravity
        self.physics_engine = arcade.PhysicsEnginePlatformer(self.player_sprite, self.coin_list, GRAVITY)

        # Set the viewport boundaries
        # These numbers set where we have 'scrolled' to.
        self.view_left = 0
        self.view_bottom = 0

    def on_show(self):
        arcade.set_background_color(arcade.color.SAE)

    def on_draw(self):
        arcade.start_render()
        self.bullet_list.draw()

        arcade.draw_text("Press Esc. to pause",
                         WIDTH / 10.0,
                         HEIGHT - 40,
                         arcade.color.BLACK,
                         font_size=10,
                         anchor_x="center")

        # background is sky blue, draw the water and the line.
        makeWaves(self)

        for ball in self.ball_list:
            arcade.draw_circle_filled(ball.x, ball.y, ball.size, ball.color)

        # Draw all the sprites.
        self.shape_list.draw()
        self.player_list.draw()
        self.coin_list.draw()

        # Put the text on the screen.
        output = f"Score: {self.score}"
        arcade.draw_text(output, 10, 50, arcade.color.WHITE, 14)
        output_total = f"Total Score: {self.window.total_score}"
        arcade.draw_text(output_total, 10, 30, arcade.color.WHITE, 14)
        output_total = f"Music Credit: {MUSIC_NAME}"
        arcade.draw_text(output_total, 10, 10, arcade.color.WHITE, 14)

    def on_key_press(self, key, modifiers):
        """Called whenever a key is pressed. """

        if key == arcade.key.UP:
            self.player_sprite.change_y = PLAYER_JUMP_SPEED
        elif key == arcade.key.DOWN:
            self.player_sprite.change_y = -MOVEMENT_SPEED
        elif key == arcade.key.LEFT:
            self.player_sprite.change_x = -MOVEMENT_SPEED
        elif key == arcade.key.RIGHT:
            self.player_sprite.change_x = MOVEMENT_SPEED
        # cj
        if key == arcade.key.UP:
            self.up_pressed = True
        elif key == arcade.key.DOWN:
            self.down_pressed = True
        elif key == arcade.key.LEFT:
            self.left_pressed = True
        elif key == arcade.key.RIGHT:
            self.right_pressed = True
        if key == arcade.key.ESCAPE:
            # pass self, the current view, to preserve this view's state
            pause = PauseView(self)
            self.window.show_view(pause)

    def on_key_release(self, key, modifiers):
        """Called when the user releases a key. """

        if key == arcade.key.UP or key == arcade.key.DOWN:
            self.player_sprite.change_y = 0

        elif key == arcade.key.LEFT or key == arcade.key.RIGHT:
            self.player_sprite.change_x = 0

        if key == arcade.key.UP:
            self.up_pressed = False
        elif key == arcade.key.DOWN:
            self.down_pressed = False
        elif key == arcade.key.LEFT:
            self.left_pressed = False
        elif key == arcade.key.RIGHT:
            self.right_pressed = False

    def on_update(self, delta_time):
        """updates screen for avatar movement, screen scrolling, coin collection"""
        self.time_taken += delta_time

        """ Movement of wave across screen and game logic """
        for ball in self.ball_list:
            ball.x += ball.change_x
            ball.y += ball.change_y

            if ball.x < ball.size:
                ball.change_x *= 1

            if ball.y < ball.size:
                ball.change_y *= -1

            if ball.x > SCREEN_WIDTH - ball.size:
                ball.change_x *= 1

            if ball.y > SCREEN_HEIGHT - ball.size:
                ball.change_y *= -1
        # cj

        if self.up_pressed and not self.down_pressed:
            self.player_sprite.change_y = MOVEMENT_SPEED
        elif self.down_pressed and not self.up_pressed:
            self.player_sprite.change_y = -MOVEMENT_SPEED
        if self.left_pressed and not self.right_pressed:
            self.player_sprite.change_x = -MOVEMENT_SPEED
        elif self.right_pressed and not self.left_pressed:
            self.player_sprite.change_x = MOVEMENT_SPEED

        # time to create a new wave?
        makeBall = random.randrange(75)
        if makeBall < 2:
            ball = make_ball()
            self.ball_list.append(ball)

        # Call update on all sprites
        self.physics_engine.update()
        self.shape_list.draw()
        self.coin_list.update()
        self.player_list.update()

        # --- Manage Scrolling ---

        # Keep track of if we changed the boundary. We don't want to call the
        # set_viewport command if we didn't change the view port.
        changed = False
        gameOver = False
        gameWin = False
        """
        If the player gets overtaken by the left side of the screen, game over
        """
        left_boundary = self.view_left + VIEWPORT_MARGIN
        fallOff = self.view_left - self.player_sprite.left
        if self.player_sprite.left < 10 or fallOff >= 1:
            self.view_left -= left_boundary - self.player_sprite.left
            changed = True
            gameOver = True

        """This is the code to make the screen scroll to the right
        player has to get to manually move 1/4 of the screen to get things moving
        """
        # Scroll right automatically
        right_boundary = self.view_left + SCREEN_WIDTH - VIEWPORT_MARGIN
        if self.player_sprite.right > SCREEN_WIDTH / 4:
            # self.view_left += self.player_sprite.right - right_boundary
            self.view_left += 1
            changed = True

        # Scroll right because of player
        if self.player_sprite.right > right_boundary:
            self.view_left += self.player_sprite.right - right_boundary
            changed = True

        # cannot scroll up or scroll down.  This game is a horizontal game only
        # do not Scroll up, sprite stays on edge
        if self.player_sprite.top > SCREEN_HEIGHT:
            self.player_sprite.top = SCREEN_HEIGHT

        # do not Scroll down, sprite stays on edge
        if self.player_sprite.bottom < 1:
            self.player_sprite.bottom = 1

        # Make sure our boundaries are integer values. While the view port does
        # support floating point numbers, for this application we want every pixel
        # in the view port to map directly onto a pixel on the screen. We don't want
        # any rounding errors.
        self.view_left = int(self.view_left)
        self.view_bottom = int(self.view_bottom)

        # If we changed the boundary values, update the view port to match
        if changed:
            arcade.set_viewport(self.view_left,
                                SCREEN_WIDTH + self.view_left,
                                self.view_bottom,
                                SCREEN_HEIGHT + self.view_bottom)

            # time to make more coins?
            makeCoin = random.randrange(100)
            if makeCoin < 2:
                makeCoins(self, right_boundary)

        # Generate a list of all sprites that collided with the player.
        hit_list = arcade.check_for_collision_with_list(self.player_sprite, self.coin_list)

        # Loop through each colliding sprite, remove it, and add to the
        # score.
        for coin in hit_list:
            coin.kill()
            self.score += 1
            self.window.total_score += 1

        # If we've collected all the treasure, then move to a "GAME_OVER with a WIN"
        # state.
        if len(self.coin_list) == 0 or self.score > WIN_COINS:
            gameOver = True
            gameWin = True

        if gameOver or gameWin:
            self.music.stop()
            if gameWin:
                game_over_view = GameOverWinView()
            else:
                game_over_view = GameOverView()
                self.window.total_score = 0
            game_over_view.time_taken = self.time_taken
            self.window.set_mouse_visible(True)
            self.window.show_view(game_over_view)

    def on_mouse_motion(self, x, y, _dx, _dy):
        """
        Disable the mouse during game play.
        self.player_sprite.center_x = x
        self.player_sprite.center_y = y
        """


class PauseView(arcade.View):
    def __init__(self, game_view):
        super().__init__()
        self.game_view = game_view

    def on_show(self):
        arcade.set_background_color(arcade.color.SAE)

    def on_draw(self):
        arcade.start_render()

        arcade.draw_lrtb_rectangle_filled(0, 1000, 150, 0, arcade.csscolor.ROYAL_BLUE)
        # sun
        arcade.draw_circle_filled(500, 550, 40, arcade.color.YELLOW)

        # Rays to the left, right, up, and down
        arcade.draw_line(500, 550, 400, 550, arcade.color.YELLOW, 3)
        arcade.draw_line(500, 550, 600, 550, arcade.color.YELLOW, 3)
        arcade.draw_line(500, 550, 500, 450, arcade.color.YELLOW, 3)
        arcade.draw_line(500, 550, 500, 650, arcade.color.YELLOW, 3)

        # Diagonal rays
        arcade.draw_line(500, 550, 550, 600, arcade.color.YELLOW, 3)
        arcade.draw_line(500, 550, 550, 500, arcade.color.YELLOW, 3)
        arcade.draw_line(500, 550, 450, 600, arcade.color.YELLOW, 3)
        arcade.draw_line(500, 550, 450, 500, arcade.color.YELLOW, 3)

        arcade.draw_line(250, 30, 50, 30, arcade.color.WHITE, 3)
        arcade.draw_line(150, 45, 0, 45, arcade.color.WHITE, 3)
        arcade.draw_line(250, 60, 50, 60, arcade.color.WHITE, 3)
        arcade.draw_line(150, 75, 0, 75, arcade.color.WHITE, 3)
        arcade.draw_line(250, 90, 50, 90, arcade.color.WHITE, 3)
        arcade.draw_line(150, 105, 0, 105, arcade.color.WHITE, 3)
        arcade.draw_line(250, 120, 50, 120, arcade.color.WHITE, 3)
        arcade.draw_line(150, 135, 0, 135, arcade.color.WHITE, 3)
        arcade.draw_line(175, 135, 375, 135, arcade.color.WHITE, 3)
        arcade.draw_line(175, 105, 375, 105, arcade.color.WHITE, 3)
        arcade.draw_line(175, 75, 375, 75, arcade.color.WHITE, 3)
        arcade.draw_line(175, 45, 375, 45, arcade.color.WHITE, 3)
        arcade.draw_line(275, 60, 475, 60, arcade.color.WHITE, 3)
        arcade.draw_line(275, 90, 475, 90, arcade.color.WHITE, 3)
        arcade.draw_line(275, 120, 475, 120, arcade.color.WHITE, 3)
        arcade.draw_line(400, 135, 600, 135, arcade.color.WHITE, 3)
        arcade.draw_line(400, 105, 600, 105, arcade.color.WHITE, 3)
        arcade.draw_line(400, 75, 600, 75, arcade.color.WHITE, 3)
        arcade.draw_line(500, 120, 700, 120, arcade.color.WHITE, 3)
        arcade.draw_line(500, 90, 700, 90, arcade.color.WHITE, 3)
        arcade.draw_line(625, 105, 825, 105, arcade.color.WHITE, 3)
        arcade.draw_line(625, 135, 825, 135, arcade.color.WHITE, 3)

        # Draw player, for effect, on pause screen.
        # The previous View (GameView) was passed in
        # and saved in self.game_view.
        player_sprite = self.game_view.player_sprite
        player_sprite.draw()

        # draw an orange filter over him
        arcade.draw_lrtb_rectangle_filled(left=player_sprite.left,
                                          right=player_sprite.right,
                                          top=player_sprite.top,
                                          bottom=player_sprite.bottom,
                                          color=arcade.color.ORANGE + (200,))

        arcade.draw_text("GAME PAUSED", WIDTH / 2, HEIGHT / 2 + 25
                         ,
                         arcade.color.BLACK, font_size=64, anchor_x="center")

        # Show tip to return or reset
        arcade.draw_text("Press  Escape  to  Shred",
                         WIDTH / 2,
                         HEIGHT / 2.7,
                         arcade.color.BLACK,
                         font_size=20,
                         anchor_x="center")
        arcade.draw_text("Press Enter to Start Over",
                         WIDTH / 2,
                         HEIGHT / 3.2,
                         arcade.color.BLACK,
                         font_size=20,
                         anchor_x="center")

    def on_key_press(self, key, _modifiers):
        if key == arcade.key.ESCAPE:  # resume game
            self.window.show_view(self.game_view)
        elif key == arcade.key.ENTER:  # reset game
            game_view = GameView()
            game_view.setup()
            self.window.show_view(game_view)


class GameOverView(arcade.View):
    """Game over screen, mouse click to restart game"""

    def __init__(self):
        super().__init__()
        self.time_taken = 0

    def on_show(self):
        arcade.set_background_color(arcade.color.SAE)
        arcade.play_sound(GAME_OVER_SOUND)

        # Reset the viewport, necessary if we have a scrolling game and we need
        # to reset the viewport back to the start so we can see what we draw.
        arcade.set_viewport(0, SCREEN_WIDTH - 1, 0, SCREEN_HEIGHT - 1)

    def on_draw(self):
        arcade.start_render()
        """
        Draw "Game over" across the screen.
        """

        arcade.draw_lrtb_rectangle_filled(0, 1000, 150, 0, arcade.csscolor.ROYAL_BLUE)

        # sun
        arcade.draw_circle_filled(500, 550, 40, arcade.color.YELLOW)

        # Rays to the left, right, up, and down
        arcade.draw_line(500, 550, 400, 550, arcade.color.YELLOW, 3)
        arcade.draw_line(500, 550, 600, 550, arcade.color.YELLOW, 3)
        arcade.draw_line(500, 550, 500, 450, arcade.color.YELLOW, 3)
        arcade.draw_line(500, 550, 500, 650, arcade.color.YELLOW, 3)

        # Diagonal rays
        arcade.draw_line(500, 550, 550, 600, arcade.color.YELLOW, 3)
        arcade.draw_line(500, 550, 550, 500, arcade.color.YELLOW, 3)
        arcade.draw_line(500, 550, 450, 600, arcade.color.YELLOW, 3)
        arcade.draw_line(500, 550, 450, 500, arcade.color.YELLOW, 3)

        arcade.draw_line(250, 30, 50, 30, arcade.color.WHITE, 3)
        arcade.draw_line(150, 45, 0, 45, arcade.color.WHITE, 3)
        arcade.draw_line(250, 60, 50, 60, arcade.color.WHITE, 3)
        arcade.draw_line(150, 75, 0, 75, arcade.color.WHITE, 3)
        arcade.draw_line(250, 90, 50, 90, arcade.color.WHITE, 3)
        arcade.draw_line(150, 105, 0, 105, arcade.color.WHITE, 3)
        arcade.draw_line(250, 120, 50, 120, arcade.color.WHITE, 3)
        arcade.draw_line(150, 135, 0, 135, arcade.color.WHITE, 3)
        arcade.draw_line(175, 135, 375, 135, arcade.color.WHITE, 3)
        arcade.draw_line(175, 105, 375, 105, arcade.color.WHITE, 3)
        arcade.draw_line(175, 75, 375, 75, arcade.color.WHITE, 3)
        arcade.draw_line(175, 45, 375, 45, arcade.color.WHITE, 3)
        arcade.draw_line(275, 60, 475, 60, arcade.color.WHITE, 3)
        arcade.draw_line(275, 90, 475, 90, arcade.color.WHITE, 3)
        arcade.draw_line(275, 120, 475, 120, arcade.color.WHITE, 3)
        arcade.draw_line(400, 135, 600, 135, arcade.color.WHITE, 3)
        arcade.draw_line(400, 105, 600, 105, arcade.color.WHITE, 3)
        arcade.draw_line(400, 75, 600, 75, arcade.color.WHITE, 3)
        arcade.draw_line(500, 120, 700, 120, arcade.color.WHITE, 3)
        arcade.draw_line(500, 90, 700, 90, arcade.color.WHITE, 3)
        arcade.draw_line(625, 105, 825, 105, arcade.color.WHITE, 3)
        arcade.draw_line(625, 135, 825, 135, arcade.color.WHITE, 3)

        arcade.draw_text("Game Over", WIDTH / 2, HEIGHT / 2,
                         arcade.color.BLACK, font_size=64, anchor_x="center")
        arcade.draw_text("Click to restart", WIDTH / 2, HEIGHT / 2 - 50,
                         arcade.color.BLACK, font_size=20, anchor_x="center")

        time_taken_formatted = f"{round(self.time_taken, 2)} seconds"

        arcade.draw_text(f"Time taken: {time_taken_formatted}",WIDTH / 2, 160, arcade.color.BLACK,
                         font_size=15,
                         anchor_x="center")

        output_total = f"Total Score: {self.window.total_score}"
        arcade.draw_text(output_total, 10, 7, arcade.color.BLACK, 14)

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        arcade.play_sound(GAME_BEGIN_SOUND)
        game_view = GameView()
        game_view.setup()
        self.window.show_view(game_view)


class GameOverWinView(arcade.View):
    """Game Win screen, mouse click to restart game"""

    def __init__(self):
        super().__init__()
        self.time_taken = 0

    def on_show(self):
        arcade.set_background_color(arcade.color.SAE)
        # Reset the viewport, necessary if we have a scrolling game and we need
        # to reset the viewport back to the start so we can see what we draw.
        arcade.set_viewport(0, SCREEN_WIDTH - 1, 0, SCREEN_HEIGHT - 1)
        arcade.play_sound(GAME_WON_SOUND)

    def on_draw(self):
        arcade.start_render()
        """
        Draw "Game over" across the screen.
        """
        # ocean rectangle
        arcade.draw_lrtb_rectangle_filled(0, 1000, 150, 0, arcade.csscolor.ROYAL_BLUE)

        # sun
        arcade.draw_circle_filled(500, 550, 40, arcade.color.YELLOW)

        # Rays to the left, right, up, and down
        arcade.draw_line(500, 550, 400, 550, arcade.color.YELLOW, 3)
        arcade.draw_line(500, 550, 600, 550, arcade.color.YELLOW, 3)
        arcade.draw_line(500, 550, 500, 450, arcade.color.YELLOW, 3)
        arcade.draw_line(500, 550, 500, 650, arcade.color.YELLOW, 3)

        # Diagonal rays
        arcade.draw_line(500, 550, 550, 600, arcade.color.YELLOW, 3)
        arcade.draw_line(500, 550, 550, 500, arcade.color.YELLOW, 3)
        arcade.draw_line(500, 550, 450, 600, arcade.color.YELLOW, 3)
        arcade.draw_line(500, 550, 450, 500, arcade.color.YELLOW, 3)

        arcade.draw_line(250, 30, 50, 30, arcade.color.WHITE, 3)
        arcade.draw_line(150, 45, 0, 45, arcade.color.WHITE, 3)
        arcade.draw_line(250, 60, 50, 60, arcade.color.WHITE, 3)
        arcade.draw_line(150, 75, 0, 75, arcade.color.WHITE, 3)
        arcade.draw_line(250, 90, 50, 90, arcade.color.WHITE, 3)
        arcade.draw_line(150, 105, 0, 105, arcade.color.WHITE, 3)
        arcade.draw_line(250, 120, 50, 120, arcade.color.WHITE, 3)
        arcade.draw_line(150, 135, 0, 135, arcade.color.WHITE, 3)
        arcade.draw_line(175, 135, 375, 135, arcade.color.WHITE, 3)
        arcade.draw_line(175, 105, 375, 105, arcade.color.WHITE, 3)
        arcade.draw_line(175, 75, 375, 75, arcade.color.WHITE, 3)
        arcade.draw_line(175, 45, 375, 45, arcade.color.WHITE, 3)
        arcade.draw_line(275, 60, 475, 60, arcade.color.WHITE, 3)
        arcade.draw_line(275, 90, 475, 90, arcade.color.WHITE, 3)
        arcade.draw_line(275, 120, 475, 120, arcade.color.WHITE, 3)
        arcade.draw_line(400, 135, 600, 135, arcade.color.WHITE, 3)
        arcade.draw_line(400, 105, 600, 105, arcade.color.WHITE, 3)
        arcade.draw_line(400, 75, 600, 75, arcade.color.WHITE, 3)
        arcade.draw_line(500, 120, 700, 120, arcade.color.WHITE, 3)
        arcade.draw_line(500, 90, 700, 90, arcade.color.WHITE, 3)
        arcade.draw_line(625, 105, 825, 105, arcade.color.WHITE, 3)
        arcade.draw_line(625, 135, 825, 135, arcade.color.WHITE, 3)

        arcade.draw_text("DUDE", WIDTH / 2, HEIGHT / 2 + 25,
                         arcade.color.BLACK, font_size=64, anchor_x="center")
        arcade.draw_text("You Won!", WIDTH / 2, HEIGHT / 2 - 70,
                         arcade.color.BLACK, font_size=50, anchor_x="center")
        arcade.draw_text("Click to Play Again", WIDTH / 20,
                         HEIGHT - 40, arcade.color.BLACK, 20)
        # arcade.draw_text("Click to Play Again", WIDTH / 2, HEIGHT / 2 - 70,
                         # arcade.color.BLACK, font_size=20, anchor_x="center")

        time_taken_formatted = f"{round(self.time_taken, 2)} seconds"
        arcade.draw_text(f"Time taken: {time_taken_formatted}",
                         WIDTH / 2,
                         160,
                         arcade.color.BLACK,
                         font_size=15,
                         anchor_x="center")

        output_total = f"Total Score: {self.window.total_score}"
        arcade.draw_text(output_total, 10, 7, arcade.color.BLACK, 14)

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        arcade.play_sound(GAME_BEGIN_SOUND)
        game_view = GameView()
        game_view.setup()
        self.window.show_view(game_view)


def main():
    """Game starts here"""
    window = arcade.Window(WIDTH, HEIGHT, SCREEN_TITLE)
    window.total_score = 0
    menu_view = MenuView()
    window.show_view(menu_view)
    arcade.run()


if __name__ == "__main__":
    main()
